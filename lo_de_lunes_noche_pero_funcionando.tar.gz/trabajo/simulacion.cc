#include <ns3/core-module.h>
#include <ns3/network-module.h>
#include <ns3/csma-module.h>
#include <ns3/internet-module.h>
#include <ns3/point-to-point-module.h>
#include <ns3/applications-module.h>
#include <ns3/ipv4-global-routing-helper.h>
#include "ns3/drop-tail-queue.h"
#include "ns3/ipv4-queue-disc-item.h"
#include "ns3/pfifo-fast-queue-disc.h"
#include "ns3/ipv6-queue-disc-item.h"
#include "ns3/enum.h"
#include "ns3/uinteger.h"
#include "ns3/pointer.h"
#include "ns3/object-factory.h"
#include "ns3/traffic-control-module.h"
#include "ns3/socket.h"
#include "voip.h"
#include "ftp.h"
#include "http.h"

#define TSTUDENT 1.8331               //10 Simulaciones con 90% de intervalo de confianza

#define TASA 5000000

#define T_INICIO 1
#define T_FINAL 10 // o 40
#define NUM_SIMU 1        // ¡Cambiar a más!

#define PORT_HTTP 80
#define PORT_FTP 20
#define PORT_VOIP 50

#define TOS_VOIP 184 
#define TOS_FTP 40
#define TOS_HTTP 0

#define MaxQUEUINGPackets 10

using namespace ns3;
NS_LOG_COMPONENT_DEFINE ("Trabajo");

int simulacion (uint32_t nCsma, DataRate tasa_izquierda, DataRate tasa_derecha, DataRate tasa_cuello, double t_retardo_cuello, double t_retardo_izquierda, double t_retardo_derecha, uint32_t equiposVoIP, uint32_t equiposFTP, uint32_t equiposHTTP ) 
  {
  NS_LOG_INFO ("Creando Topologia");
  
  double maxHablando=0.2;
  double minHablando=0.1;
  double maxSilencio=0.8;
  double minSilencio=0.9;
  
  double maxOnHTTP=2;
  double minOnHTTP=1;
  double maxOffHTTP=0;
  double minOffHTTP=0.01;
  
  //Manejador de escenario
  Escenario escenario;
  // Nodos que pertenecen al enlace punto a punto
  NodeContainer p2pNodes;
  p2pNodes.Create (2);
  
  // Nodos que pertenecen a la red de área local de la Derecha
  // El primer nodo el encaminador que proporciona acceso al enlace p2p.
  NodeContainer csmaNodesDerecha;
  csmaNodesDerecha.Add (p2pNodes.Get (1));
  csmaNodesDerecha.Create (nCsma);
    // Nodos que pertenecen a la red de área local de la Izquierda
  // El primer nodo el encaminador que proporciona acceso al enlace p2p.
  NodeContainer csmaNodesIzquierda;
  csmaNodesIzquierda.Add (p2pNodes.Get (0));
  csmaNodesIzquierda.Create (nCsma);

  
  //Instalamos el dispositivo en los nodos punto a punto
  PointToPointHelper pointToPoint;
  NetDeviceContainer p2pDevices;
  pointToPoint.SetDeviceAttribute ("DataRate", DataRateValue (DataRate (tasa_cuello))); // Hay que editar los datos
  pointToPoint.SetChannelAttribute ("Delay", TimeValue (Time (t_retardo_cuello)));// Hay que editar los datos
  p2pDevices = pointToPoint.Install (p2pNodes);

  //Asignamos la cola a los dispositivos instalados
  pointToPoint.SetQueue("ns3::PfifoFastQueueDisc","Limit",UintegerValue(MaxQUEUINGPackets));
  
  // Instalamos el dispositivo de red en los nodos de las LAN
  // Instalamos el dispositivo de red en los nodos de las LAN
  CsmaHelper csmaDerecha;
  NetDeviceContainer csmaDevicesDerecha;
  csmaDerecha.SetChannelAttribute ("DataRate", DataRateValue (DataRate (tasa_derecha)));// Hay que editar los datos
  csmaDerecha.SetChannelAttribute ("Delay", TimeValue (Time (t_retardo_derecha))); // Hay que editar los datos
  csmaDevicesDerecha = csmaDerecha.Install (csmaNodesDerecha);

  CsmaHelper csmaIzquierda;
  NetDeviceContainer csmaDevicesIzquierda;
  csmaIzquierda.SetChannelAttribute ("DataRate", DataRateValue (DataRate (tasa_izquierda)));// Hay que editar los datos
  csmaIzquierda.SetChannelAttribute ("Delay", TimeValue (Time (t_retardo_izquierda)));// Hay que editar los datos
  csmaDevicesIzquierda = csmaIzquierda.Install (csmaNodesIzquierda);
  
  //Se monta la pila de protocolos
  InternetStackHelper stack;
  stack.Install (csmaNodesIzquierda);
  stack.Install (csmaNodesDerecha);
  
  //----------------------------------------------------------------------------
  // Asignamos direcciones a cada una de las interfaces
  // Utilizamos dos rangos de direcciones diferentes:
  //    - un rango para los dos nodos del enlace p2p
  //    - un rango para los nodos de la red de área local izquierda.
  //    - un rango para los nodos de la red de área local derecha.
  //----------------------------------------------------------------------------

  Ipv4AddressHelper address;
  //Network de los dos nodos del enlace punto a punto
  Ipv4InterfaceContainer p2pInterfaces;
  address.SetBase ("10.0.0.0", "255.255.255.0");
  p2pInterfaces = address.Assign (p2pDevices);
  //Network de CSMA Izquierda
  Ipv4InterfaceContainer csmaIzquierdaInterfaces;
  address.SetBase ("10.1.1.0", "255.255.255.0");
  csmaIzquierdaInterfaces = address.Assign (csmaDevicesIzquierda);
  //Network de CSMA Derecha
  Ipv4InterfaceContainer csmaDerechaInterfaces;
  address.SetBase ("10.2.2.0", "255.255.255.0");
  csmaDerechaInterfaces = address.Assign (csmaDevicesDerecha);
  
  // Calculamos las rutas del escenario.
  Ipv4GlobalRoutingHelper::PopulateRoutingTables ();  
  
  //----------------------------------------------------------------------------
  NS_LOG_INFO ("Añadiendo aplicaciones...");
  //----------------------------------------------------------------------------
  // 1) Sumideros
  NS_LOG_INFO ("Instalando sumideros");
  PacketSinkHelper sinkUdp ("ns3::UdpSocketFactory", Address (InetSocketAddress (Ipv4Address::GetAny(), PORT_VOIP)));
  PacketSinkHelper sinkFtp ("ns3::TcpSocketFactory", Address (InetSocketAddress (Ipv4Address::GetAny(), PORT_FTP)));
  PacketSinkHelper sinkHTTP ("ns3::UdpSocketFactory", Address (InetSocketAddress (Ipv4Address::GetAny(), PORT_HTTP)));

  for (unsigned index_ftp = 1; index_ftp < (equiposFTP+1); index_ftp++) 
  {
    NS_LOG_INFO ("Instalando sumidero para FTP en " << csmaIzquierdaInterfaces.GetAddress(index_ftp));
    ApplicationContainer appFTPIzq = sinkFtp.Install (csmaNodesIzquierda.Get(index_ftp));
    appFTPIzq.Start (Seconds (T_INICIO));
    appFTPIzq.Stop (Seconds (T_FINAL));
  
    NS_LOG_INFO ("Instalando sumidero para FTP en " << csmaDerechaInterfaces.GetAddress(index_ftp));
    ApplicationContainer appFTPDer = sinkFtp.Install (csmaNodesDerecha.Get(index_ftp));
    appFTPDer.Start (Seconds (T_INICIO));
    appFTPDer.Stop (Seconds (T_FINAL));
  }
  
  for (unsigned index_voip = 1+equiposFTP; index_voip < (equiposFTP+1+equiposVoIP); index_voip++) 
  {
    NS_LOG_INFO ("Instalando sumidero para VoIP en " << csmaIzquierdaInterfaces.GetAddress(index_voip));
    ApplicationContainer appVoipizq  = sinkUdp.Install (csmaNodesIzquierda.Get(index_voip));
    appVoipizq.Start (Seconds (T_INICIO));
    appVoipizq.Stop (Seconds (T_FINAL));
    
    NS_LOG_INFO ("Instalando sumidero para VoIP en " << csmaDerechaInterfaces.GetAddress(index_voip));
    ApplicationContainer appVoipder  = sinkUdp.Install (csmaNodesDerecha.Get(index_voip));
    appVoipder.Start (Seconds (T_INICIO));
    appVoipder.Stop (Seconds (T_FINAL));
  }
  
  for (unsigned index_http = 1+equiposFTP+equiposVoIP; index_http < (1+equiposFTP+equiposVoIP+equiposHTTP); index_http++) 
  {
    NS_LOG_INFO ("Instalando sumidero para HTTP en " << csmaIzquierdaInterfaces.GetAddress(index_http));
    ApplicationContainer appHTTPizq = sinkHTTP.Install  (csmaNodesIzquierda.Get(index_http));
    appHTTPizq.Start (Seconds (T_INICIO));
    appHTTPizq.Stop (Seconds (T_FINAL));
  
    NS_LOG_INFO ("Instalando sumidero para HTTP en " << csmaDerechaInterfaces.GetAddress(index_http));
    ApplicationContainer appHTTPder = sinkHTTP.Install  (csmaNodesDerecha.Get(index_http));
    appHTTPder.Start (Seconds (T_INICIO));
    appHTTPder.Stop (Seconds (T_FINAL));
  }
  //----------------------------------------------------------------------------
  // 2) Servidores FTP
  for (unsigned index_ftp = 1; index_ftp < (equiposFTP+1); index_ftp++) 
  {
    InetSocketAddress socketAddressFTPDer (csmaIzquierdaInterfaces.GetAddress (index_ftp), PORT_FTP);
    socketAddressFTPDer.SetTos(TOS_FTP);
    FTPHelper ftpDerecha (csmaIzquierdaInterfaces.GetAddress (index_ftp), PORT_FTP,socketAddressFTPDer);
    ApplicationContainer appFtpDerecha = ftpDerecha.Install (csmaNodesDerecha.Get(index_ftp));
    NS_LOG_INFO ("Instalando app FTP en " << csmaDerechaInterfaces.GetAddress (index_ftp));
    appFtpDerecha.Start (Seconds (T_INICIO));
    appFtpDerecha.Stop (Seconds (T_FINAL));

    InetSocketAddress socketAddressFTPIzq (csmaDerechaInterfaces.GetAddress (index_ftp), PORT_FTP);
    socketAddressFTPIzq.SetTos(TOS_FTP);
    FTPHelper ftpIzquierda (csmaDerechaInterfaces.GetAddress (index_ftp), PORT_FTP,socketAddressFTPIzq);
    ApplicationContainer appFtpIzquierda = ftpIzquierda.Install (csmaNodesIzquierda.Get(index_ftp));
    NS_LOG_INFO ("Instalando app FTP en " << csmaIzquierdaInterfaces.GetAddress (index_ftp));
    appFtpIzquierda.Start(Seconds (T_INICIO));
    appFtpIzquierda.Stop(Seconds (T_FINAL));
  }
  //----------------------------------------------------------------------------
  // 3) "Teléfono" IP
  for (unsigned index_voip = 1+equiposFTP; index_voip < (equiposFTP+1+equiposVoIP); index_voip++) 
  {
    InetSocketAddress socketAddresstelDer (csmaIzquierdaInterfaces.GetAddress (index_voip),PORT_VOIP);
    socketAddresstelDer.SetTos(TOS_VOIP);
    VoipHelper telefonoDerecha (csmaIzquierdaInterfaces.GetAddress (index_voip), PORT_VOIP, maxHablando, minHablando, maxSilencio, minSilencio,socketAddresstelDer);
    ApplicationContainer appVoipDerecha = telefonoDerecha.Install(csmaNodesDerecha.Get(index_voip));
    appVoipDerecha.Start(Seconds (T_INICIO));
    appVoipDerecha.Stop(Seconds (T_FINAL));
      
    InetSocketAddress socketAddresstelIzq (csmaDerechaInterfaces.GetAddress (index_voip),PORT_VOIP);
    socketAddresstelIzq.SetTos(TOS_VOIP);
    VoipHelper telefonoIzquierda (csmaDerechaInterfaces.GetAddress (index_voip), PORT_VOIP, maxHablando, minHablando, maxSilencio, minSilencio,socketAddresstelIzq);
    ApplicationContainer appVoipIzquierda = telefonoIzquierda.Install (csmaNodesIzquierda.Get(index_voip)); //nodo en el que se instala
    appVoipIzquierda.Start(Seconds (T_INICIO));
    appVoipIzquierda.Stop(Seconds (T_FINAL));
  }  
  //----------------------------------------------------------------------------
  // 4) Aplicación HTTP
  for (unsigned index_http = 1+equiposFTP+equiposVoIP; index_http < (1+equiposFTP+equiposVoIP+equiposHTTP); index_http++) 
  {
    InetSocketAddress socketAddressHTTPDer (csmaIzquierdaInterfaces.GetAddress (index_http), PORT_HTTP);
    socketAddressHTTPDer.SetTos(TOS_HTTP);
    HTTPHelper httpDerecha (csmaIzquierdaInterfaces.GetAddress (index_http), PORT_HTTP, maxOnHTTP, minOnHTTP, maxOffHTTP, minOffHTTP,socketAddressHTTPDer);
    ApplicationContainer apphttpDerecha = httpDerecha.Install (csmaNodesDerecha.Get(index_http));
    apphttpDerecha.Start(Seconds (T_INICIO));
    apphttpDerecha.Stop(Seconds (T_FINAL));

    InetSocketAddress socketAddressHTTPIzq (csmaDerechaInterfaces.GetAddress (index_http), PORT_HTTP);
    socketAddressHTTPDer.SetTos(TOS_HTTP);
    HTTPHelper httpIzquierda (csmaDerechaInterfaces.GetAddress (index_http), PORT_HTTP, maxOnHTTP, minOnHTTP, maxOffHTTP, minOffHTTP,socketAddressHTTPIzq );
      ApplicationContainer apphttpIzquierda = httpIzquierda.Install (csmaNodesIzquierda.Get(index_http));
      apphttpIzquierda.Start(Seconds (T_INICIO));
      apphttpIzquierda.Stop(Seconds (T_FINAL));

  }
  //----------------------------------------------------------------------------
  // ACTIVAR PCAP
  for (unsigned indice = 0; indice < nCsma; indice++) 
  {
   csmaIzquierda.EnablePcap ("CSMAizq", csmaDevicesIzquierda.Get (indice), false);
   csmaDerecha.EnablePcap ("CSMAder", csmaDevicesDerecha.Get (indice), false);
 }
  //----------------------------------------------------------------------------
  NS_LOG_INFO ("Ejecutando simulacion...");
  Simulator::Stop(Seconds(10));
  Simulator::Run();
  Simulator::Destroy ();
  NS_LOG_INFO ("Done");
  return 0;  //retornará el estadistico que recoja el observador
  }
  
int
main (int argc, char *argv[])
{
  LogComponentEnable("Trabajo", LOG_LEVEL_ALL); // ¡¡SÓLO PARA DEBUG, BORRAR AL FINAL!!
  GlobalValue::Bind("ChecksumEnabled", BooleanValue(true));
  Time::SetResolution (Time::NS);
  
  uint32_t nCsma = 5; //numero total de equipos en las CSMA (serán siempre SIMÉTRICAS)
  uint32_t equiposHTTP = 1;
  uint32_t equiposVoIP = 2;
  uint32_t equiposFTP  = 1;
  double t_retardo_min           = 0.002;
  double t_retardo_max           = 0.012;
  double t_retardo_actual;
  double t_retardo_paso; 
  double t_retardo_izquierda    = 0.002;
  double t_retardo_derecha      = 0.002;
  DataRate tasa_izquierda        ("100Mbps");
  DataRate tasa_derecha          ("100Mbps");
  DataRate tasa_cuello           ("1Gbps");
  double tasa_error;  
  
  CommandLine cmd;
  cmd.AddValue("nCsma",             "Número de nodos en las redes  CSMA",       nCsma);
  cmd.AddValue("equiposHTTP",       "Número de nodos  que usan app HTTP",       equiposHTTP);
  cmd.AddValue("equiposVoIP",       "Número de nodos  que usan app VoIP",       equiposVoIP);
  cmd.AddValue("equiposFTP",        "Número de nodos  que usan app FTP",        equiposFTP);
  cmd.AddValue("tasa_izquierda",    "Capacidad de la red CSMA izquierda",        tasa_izquierda);
  cmd.AddValue("tasa_derecha",      "Capacidad de la red CSMA derecha",          tasa_derecha);
  cmd.AddValue("tasa_cuello",       "Capacidad de la red p2p",                   tasa_cuello);
  cmd.AddValue("retraso_p2p_min",   "Retardo de la red p2p mínimo",              t_retardo_min );
  cmd.AddValue("retraso_p2p_max",   "Retardo de la red p2p mínimo",              t_retardo_max);
  cmd.AddValue("t_retardo_izquierda","Retardo de la red CSMA izquierda",         t_retardo_izquierda);
  cmd.AddValue("t_retardo_derecha", "Retardo de la red CSMA derecha",            t_retardo_derecha);
  cmd.Parse (argc, argv);
  
  if (equiposHTTP+equiposVoIP+equiposFTP == nCsma-1){
    t_retardo_paso = (t_retardo_min + t_retardo_max)/6;
    //for(t_retardo_actual = t_retardo_min; t_retardo_actual <= t_retardo_max; t_retardo_actual += t_retardo_paso){
      for(t_retardo_actual = 1; t_retardo_actual < 1.001; t_retardo_actual += t_retardo_paso){ // <-- ¡CAMBIAR! por la de arriba
      NS_LOG_INFO("El tiempo de retardo actual en el cuello es: " << t_retardo_actual);
      NS_LOG_INFO("El nº de nodos en la red es izquierda es : " << nCsma);
      for(tasa_error = 0; tasa_error <= 0; tasa_error += 0.1){  //Actalmente la tasa de error es 0 siempre, se podría cambiar
        NS_LOG_INFO("La tasa de error en el medio es : " << tasa_error);
        //for (int indice_simulaciones = 0; indice_simulaciones <= NUM_SIMU; indice_simulaciones++)
        for (int indice_simulaciones = 0; indice_simulaciones <= NUM_SIMU; indice_simulaciones++) // <-- ¡CAMBIAR! por la de arriba
          {
            int rendimiento = simulacion(nCsma, tasa_izquierda, tasa_derecha, tasa_cuello,t_retardo_actual, t_retardo_izquierda, t_retardo_derecha, equiposVoIP, equiposFTP, equiposHTTP);
            NS_LOG_INFO("Rendimiento = " << rendimiento);
          }
      }
    } 
  }
  else
  NS_LOG_ERROR("Combinación de equipos imposible. Recuerde: Numero de nodos totales = (nCsma - 1) ");
}  
