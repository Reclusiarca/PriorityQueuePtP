/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
// Ejemplos en ns3
// https://www.nsnam.org/doxygen/tcp-bulk-send_8cc_source.html
// https://groups.google.com/forum/#!topic/ns-3-users/6PGrl_Rz2KM
// https://www.nsnam.org/doxygen/examples_2virtual-net-device_8cc_source.html

#include <ns3/core-module.h>
#include <ns3/network-module.h>
#include <ns3/csma-module.h>
#include <ns3/internet-module.h>
#include <ns3/point-to-point-module.h>
#include <ns3/applications-module.h>
#include <ns3/ipv4-global-routing-helper.h>
#include "voip.h"
#include "ftp.h"
#include "http.h"


// ¿Qué hay hecho? 
 // Tres servicios (VOiP, HTTP y FTP) en ambas redes comunicandose full duplex
 // Un socket básico que se le configura el ToS 
// ¿Qué falta? 
 // 1) Asignar el socket que manipula el tos y asignarlo a las aplicaciones que existen
 // Para ello CREO que hay que usar SetAttribute 
 //
 // 2) Una vez se configuren las aplicaciones con sus sockets ToS adecuados
 // montar en los routers la cola (Un prioridad.cc que haga aquello que 
 // vimos con  manuel y que está en github)
 
 // 3 Una vez eso montar un observador.cc que haga un cálculo de uso de canal.
 // 4) Se podria elevar el numero de equipos, convirtiendo el main en un gran
 // bucle, en principio que tengo una idea de como hacerlo.
 
///
// n0 n1 n2 n3 n4 - - - - - - n5 n6 n7 n8 n9
//  | |  |  |  |              |  |  |  |  |
// ==============             =============
//      Lan1           p2p          Lan2


// Lan 1 :  10.1.1.0
// p2p   :  10.0.0.0
// Lan 2 :  10.2.2.0

//10.1.1.2  FTP   20.2.2.2
//20.1.1.3  VOiP  20.2.2.3
//20.1.1.4  HTTP  20.2.2.4

using namespace ns3;
NS_LOG_COMPONENT_DEFINE ("Trabajo");

int
main (int argc, char *argv[])
{
  LogComponentEnable("Trabajo", LOG_LEVEL_ALL); // ¡¡SÓLO PARA DEBUG, BORRAR AL FINAL!!
  GlobalValue::Bind("ChecksumEnabled", BooleanValue(true));
  Time::SetResolution (Time::NS);

  uint32_t nCsmaIzquierda = 4;
  uint32_t nCsmaDerecha = 4;
  
  double maxHablando=0.2;
  double minHablando=0.1;
  double maxSilencio=0.8;
  double minSilencio=0.9;
  
  double maxOnHTTP=0.4;
  double minOnHTTP=0.2;
  double maxOffHTTP=18;
  double minOffHTTP=12;
  
  //Time retardo=Seconds(0.2);
  
  //uint32_t tamPqt=121;
  Time tinicio=Seconds(1.0);
  Time tfinal= Seconds(10.0);
  
   uint32_t ipTos = 0;
  //bool ipRecvTos = true;
  //uint32_t ipTtl = 0;
  //bool ipRecvTtl = true; 
  int si=5;
  
  
  NS_LOG_INFO ("Creando Topologia");
  // Nodos que pertenecen al enlace punto a punto
  NodeContainer p2pNodes;
  p2pNodes.Create (2);
  // Nodos que pertenecen a la red de área local de la Derecha
  // El primer nodo el encaminador que proporciona acceso al enlace p2p.
  NodeContainer csmaNodesDerecha;
  csmaNodesDerecha.Add (p2pNodes.Get (1));
  csmaNodesDerecha.Create (nCsmaDerecha);
    // Nodos que pertenecen a la red de área local de la Izquierda
  // El primer nodo el encaminador que proporciona acceso al enlace p2p.
  NodeContainer csmaNodesIzquierda;
  csmaNodesIzquierda.Add (p2pNodes.Get (0));
  csmaNodesIzquierda.Create (nCsmaIzquierda);


  //Instalamos el dispositivo en los nodos punto a punto
  PointToPointHelper pointToPoint;
  NetDeviceContainer p2pDevices;
  pointToPoint.SetDeviceAttribute ("DataRate", DataRateValue (DataRate ("2Mbps"))); // Hay que editar los datos
  pointToPoint.SetChannelAttribute ("Delay", TimeValue (Time ("2ms")));// Hay que editar los datos
  p2pDevices = pointToPoint.Install (p2pNodes);

  // Instalamos el dispositivo de red en los nodos de las LAN
  CsmaHelper csmaDerecha;
  NetDeviceContainer csmaDevicesDerecha;
  csmaDerecha.SetChannelAttribute ("DataRate", DataRateValue (DataRate ("100Mbps")));// Hay que editar los datos
  csmaDerecha.SetChannelAttribute ("Delay", TimeValue (Time ("6560ns"))); // Hay que editar los datos
  csmaDevicesDerecha = csmaDerecha.Install (csmaNodesDerecha);

  CsmaHelper csmaIzquierda;
  NetDeviceContainer csmaDevicesIzquierda;
  csmaIzquierda.SetChannelAttribute ("DataRate", DataRateValue (DataRate ("100Mbps")));// Hay que editar los datos
  csmaIzquierda.SetChannelAttribute ("Delay", TimeValue (Time ("6560ns")));// Hay que editar los datos
  csmaDevicesIzquierda = csmaIzquierda.Install (csmaNodesIzquierda);

  //Se monta la pila de protocolos
  InternetStackHelper stack;
  stack.Install (csmaNodesIzquierda);
  stack.Install (csmaNodesDerecha);
  

  //----------------------------------------------------------------------------
  // Asignamos direcciones a cada una de las interfaces
  // Utilizamos dos rangos de direcciones diferentes:
  //    - un rango para los dos nodos del enlace p2p
  //    - un rango para los nodos de la red de área local izquierda.
  //    - un rango para los nodos de la red de área local derecha.
  //----------------------------------------------------------------------------
  
  //Network de los dos nodos del enlace punto a punto
  Ipv4AddressHelper address;
  
  Ipv4InterfaceContainer p2pInterfaces;
  address.SetBase ("10.0.0.0", "255.255.255.0");
  p2pInterfaces = address.Assign (p2pDevices);
  
  Ipv4InterfaceContainer csmaIzquierdaInterfaces;
  address.SetBase ("10.1.1.0", "255.255.255.0");
  csmaIzquierdaInterfaces = address.Assign (csmaDevicesIzquierda);

  Ipv4InterfaceContainer csmaDerechaInterfaces;
  address.SetBase ("10.2.2.0", "255.255.255.0");
  csmaDerechaInterfaces = address.Assign (csmaDevicesDerecha);
 

  // Calculamos las rutas del escenario. Con este comando, los
  //     nodos de la red de área local definen que para acceder
  //     al nodo del otro extremo del enlace punto a punto deben
  //     utilizar el primer nodo como ruta por defecto.
  Ipv4GlobalRoutingHelper::PopulateRoutingTables ();

//-----------------------------------------------------------------------------
// Aplicación de la práctica 6:
//-----------------------------------------------------------------------------
//COLA 
/*DESCOMENTAR Y CONTINUAR HACIENDOLO CUANDO FUNCIONE LO DEMAS
Ptr<PfifoFastQueueDisc> queueDisc;
queueDisc = CreateObject<PfifoFastQueueDisc> ();
for (uint16_t i = 0; i < 3; i++)
    {
      Ptr<DropTailQueue> queue = CreateObject<DropTailQueue> ();
    //  bool ok = queue->SetAttributeFailSafe ("MaxPackets", UintegerValue (1000));
      queueDisc->AddInternalQueue (queue);
    }
*/

  // Establecemos puertos para aplicaciones HTTP,VoIP,Streaming y FTP.
  // ESTAS VARIABLES DEBERÍAN SER ESTÁTICAS Y ESTAR DEFINIDAS ARRIBA DEL TODO 
  // EN MAYUS
  
  uint16_t portVOIP = 55; //puerto inventado
  uint16_t portFTP = 20;
  uint16_t portHTTP = 80;
  //uint16_t portstreaming = 1022;
  
  //0) Configuración de Sockets
  TypeId tid = TypeId::LookupByName ("ns3::UdpSocketFactory");
  Ptr<Socket> socketprueba = Socket::CreateSocket (csmaNodesDerecha.Get(2), tid);
  socketprueba->SetIpTos (ipTos);
  //
  //si = socketprueba->Bind (src);
  //InetSocketAddress remote = InetSocketAddress (csmaIzquierdaInterfaces.GetAddress (2), portVOIP);
  //si=socketprueba->Connect (remote);
  NS_LOG_INFO ("Conexion socket de prueba --> "<< si << " (O means OK, otherwise means FAIL)");
  
  
  
  
  
  
  
  NS_LOG_INFO ("Añadiendo aplicaciones");
  // 1) Sumideros
  
  PacketSinkHelper sinkUdp ("ns3::UdpSocketFactory", Address (InetSocketAddress (Ipv4Address::GetAny(), portVOIP)));
  //sinkUdp.SetAttribute ("m_socket", );  // m_socket is an Ptr< Socket > Listening socket https://www.nsnam.org/doxygen/classns3_1_1_packet_sink.html
  PacketSinkHelper sinkFtp ("ns3::TcpSocketFactory", Address (InetSocketAddress (Ipv4Address::GetAny(), portFTP)));
  PacketSinkHelper sinkHTTP ("ns3::UdpSocketFactory", Address (InetSocketAddress (Ipv4Address::GetAny(), portHTTP)));
 
 ApplicationContainer app1Izq = sinkFtp.Install ( csmaNodesIzquierda.Get(1));
 app1Izq.Start (tinicio);  //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus
 app1Izq.Stop (tfinal);  //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus
 
 
 ApplicationContainer app1Der = sinkFtp.Install ( csmaNodesDerecha.Get(1));
 app1Der.Start (tinicio);  //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus
 app1Der.Stop (tfinal);  //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus
 
 ApplicationContainer app2izq  = sinkUdp.Install  (csmaNodesIzquierda.Get(2));
 app2izq.Start (tinicio);    //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus
 app2izq.Stop (tfinal);    //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus
 
 ApplicationContainer app2der  = sinkUdp.Install  (csmaNodesDerecha.Get(2));
 app2der.Start (tinicio);    //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus
 app2der.Stop (tfinal);    //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus

 ApplicationContainer app3izq  = sinkHTTP.Install  (csmaNodesIzquierda.Get(3));
 app3izq.Start (tinicio);    //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus
 app3izq.Stop (tfinal);    //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus
 
 ApplicationContainer app3der  = sinkHTTP.Install  (csmaNodesDerecha.Get(3));
 app3der.Start (tinicio);    //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus
 app3der.Stop (tfinal);    //Los segundos deberían ser ESTÁTICOS y definidos arriba en mayus
 
// ApplicationContainer app2 = sinkHTTP.Install ( csmaNodesIzquierda.Get(3));
// ApplicationContainer app3 = sinkStreaming.Install (csmaNodesIzquierda.Get(4));
 NS_LOG_INFO ("Añadiendo telefonos VoIP");
 // 2) "Teléfono" IP
      VoipHelper telefonoDerecha (csmaIzquierdaInterfaces.GetAddress (2), portVOIP, maxHablando, minHablando, maxSilencio, minSilencio);
      ApplicationContainer appVoipDerecha = telefonoDerecha.Install (csmaNodesDerecha.Get(2));//nodo en el que se instala
      appVoipDerecha.Start (tinicio);
      appVoipDerecha.Stop (tfinal);
      
      VoipHelper telefonoIzquierda (csmaDerechaInterfaces.GetAddress (2), portVOIP, maxHablando, minHablando, maxSilencio, minSilencio);
      ApplicationContainer appVoipIzquierda = telefonoIzquierda.Install (csmaNodesIzquierda.Get(2)); //nodo en el que se instala
      appVoipIzquierda.Start (tinicio);
      appVoipIzquierda.Stop (tfinal);
 NS_LOG_INFO ("Añadiendo aplicaciones FTP");
 // 3) Servidores FTP
      FTPHelper ftpDerecha (csmaIzquierdaInterfaces.GetAddress (1), portFTP);
      ApplicationContainer appFtpDerecha = ftpDerecha.Install (csmaNodesDerecha.Get(1)); //nodo en el que se instala
      appVoipDerecha.Start (tinicio);
      appVoipDerecha.Stop (tfinal);
      FTPHelper ftpIzquierda (csmaDerechaInterfaces.GetAddress (1), portFTP);
      ApplicationContainer appFtpIzquierda = ftpIzquierda.Install (csmaNodesIzquierda.Get(1)); //nodo en el que se instala
      appVoipDerecha.Start (tinicio);
      appVoipDerecha.Stop (tfinal);
 NS_LOG_INFO ("Añadiendo aplicaciones HTTP");
 // 3) Aplicación HTTP
      HTTPHelper httpDerecha (csmaIzquierdaInterfaces.GetAddress (3), portHTTP, maxOnHTTP, minOnHTTP, maxOffHTTP, minOffHTTP);
      ApplicationContainer apphttpDerecha = httpDerecha.Install (csmaNodesDerecha.Get(1));
      apphttpDerecha.Start (tinicio);
      apphttpDerecha.Stop (tfinal);
      HTTPHelper httpIzquierda (csmaDerechaInterfaces.GetAddress (3), portHTTP, maxOnHTTP, minOnHTTP, maxOffHTTP, minOffHTTP);
      ApplicationContainer apphttpIzquierda = httpIzquierda.Install (csmaNodesIzquierda.Get(1));
      apphttpIzquierda.Start (tinicio);
      apphttpIzquierda.Stop (tfinal);
 
  
  
  //Set socket options, it is also possible to set the options after the socket has been created/connected.
 /* if (ipTos > 0)
    {
      source->SetIpTos (ipTos);
    }

  if (ipTtl > 0)
    {
      source->SetIpTtl (ipTtl);
    }
  si=source->Connect (remote); //SI CONSEGUIMOS CONECTARNOS DEVUELVE UN 0, SI NO UN -1
  std::cout <<" conexion"<< si << std::endl;
 */
 
 
  // Activamos las trazas de todas las interfaces
 csmaIzquierda.EnablePcap ("Trabajo_Izq0", csmaDevicesIzquierda.Get (0), false);//Desactivamos modo promiscuo con false
 csmaIzquierda.EnablePcap ("Trabajo_Izq1", csmaDevicesIzquierda.Get (1), false);
 csmaIzquierda.EnablePcap ("Trabajo_Izq2", csmaDevicesIzquierda.Get (2), false);
 csmaIzquierda.EnablePcap ("Trabajo_Izq3", csmaDevicesIzquierda.Get (3), false);
 csmaIzquierda.EnablePcap ("Trabajo_Izq4", csmaDevicesIzquierda.Get (4), false);
 csmaDerecha.EnablePcap ("Trabajo_Der0", csmaDevicesDerecha.Get (0), false);
 csmaDerecha.EnablePcap ("Trabajo_Der1", csmaDevicesDerecha.Get (1), false);
 csmaDerecha.EnablePcap ("Trabajo_Der2", csmaDevicesDerecha.Get (2), false);
 csmaDerecha.EnablePcap ("Trabajo_Der3", csmaDevicesDerecha.Get (3), false);
 csmaDerecha.EnablePcap ("Trabajo_Der4", csmaDevicesDerecha.Get (4), false);
 
  //NS_LOG_DEBUG("Creando la cola");
  //Prioridad prioridad;

  // Lanzamos la simulación
  Simulator::Stop(Seconds(10));
  Simulator::Run ();
  Simulator::Destroy ();

  return 0;
}
