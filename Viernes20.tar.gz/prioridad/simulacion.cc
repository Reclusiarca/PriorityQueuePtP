#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/csma-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "Prioridad.h"
#include "Voip.h"

///
// n0 n1 n2 n3 n4 - - - - - - n5 n6 n7 n8 n9
//  | |  |  |  |              |  |  |  |  |
// ==============             =============
//      Lan1           p2p          Lan2


// Lan 1 :  10.1.1.0
// p2p   :  10.0.0.0
// Lan 2 :  10.2.2.0

//n0 = equipo que genera VoIP 
//n1 = equipo que emite en streaming
//n2 = equipo que descarga HTTP
//n3 = equipo que descarga por FTP

//n4 = router de LAN 1
//n5 = router de LAN 2

//n6 = equipo que genera VoIP 
//n7 = equipo que emite en streaming
//n8 = equipo que descarga HTTP
//n9 = equipo que descarga por FTP

// ¿Qué hay hecho?

/* Bueno en principio se definen dos redes csma y una red p2p,
   como en el esquema de arriba.
   
   Se crea un NodeContainer para red CSMA Izquierda
   Se crea un NodeContainer para red CSMA Derecha
   Se crea un NodeContainer para red p2p 
   Se crea un NodeContainer para los telefonos IP de la izquierda
   Se crea un NodeContainer para los telefonos IP de la derecha
   
   He aquí una pregunta, ¿Por qué no se ha junta nodos de teléfono IP y "CSMA"?
   Por que así me parece que no van a compartir misma subred.
   
   Se montan entonces los NetDevice y se asocian a sus NodeContainer, 
   haciendo nuevamente distinción entre "CSMA" y "VoIP"
   Por cierto, en este punto comienzan a ponerse confusas los nombres de las variables
   o usamos Izquierda/Derecha ó R1/R2.
   
   Se monta la pila de protocolos y se configuran las network
   TO-DO: Meter los teléfonos IP en la misma network que los demás equipos
   
   A la hora de configurar las networks se pone una linea 
   t2->SetDefaultRoute(Ipv4Address(direccion2.Get() +1 ),1);
   para su configuración estática de IP.
   
   Se instala la aplicación.
   Pero la aplicación da problemas al ser invocada!
   ¡No funciona! y NO se cual de estas dos formas es más correcto:
      - AplicacionTelefonoIzq = new Voip();
      - Ptr<Voip> AplicacionTelefonoIzq = CreateObject<Voip> ();
   
   Después sigue estando la configuración del sumidero de la práctica 6 (?)
   */




using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("Trabajo");

int
main (int argc, char *argv[])
{
  GlobalValue::Bind("ChecksumEnabled", BooleanValue(true));
  Time::SetResolution (Time::NS);

  uint32_t nCsmaIzquierda = 4;
  uint32_t nCsmaDerecha = 4;

 
  // Nodos que pertenecen al enlace punto a punto
  NodeContainer p2pNodes;
  p2pNodes.Create (2);

  // Nodos que pertenecen a la red de área local
  // Como primer nodo añadimos el encaminador que proporciona acceso
  //      al enlace punto a punto.
  NodeContainer csmaNodesDerecha;
  csmaNodesDerecha.Add (p2pNodes.Get (1));
  csmaNodesDerecha.Create (nCsmaDerecha);
  NodeContainer csmaNodesIzquierda;
  csmaNodesIzquierda.Add (p2pNodes.Get (0));
  csmaNodesIzquierda.Create (nCsmaIzquierda);

  //Instalamos el dispositivo en los nodos punto a punto
  PointToPointHelper pointToPoint;
  NetDeviceContainer p2pDevices;
  pointToPoint.SetDeviceAttribute ("DataRate", DataRateValue (DataRate ("2Mbps"))); // Hay que editar los datos
  pointToPoint.SetChannelAttribute ("Delay", TimeValue (Time ("2ms")));// Hay que editar los datos
  p2pDevices = pointToPoint.Install (p2pNodes);

  // Instalamos el dispositivo de red en los nodos de las LAN
  CsmaHelper csmaDerecha;
  NetDeviceContainer csmaDevicesDerecha;
  csmaDerecha.SetChannelAttribute ("DataRate", DataRateValue (DataRate ("100Mbps")));// Hay que editar los datos
  csmaDerecha.SetChannelAttribute ("Delay", TimeValue (Time ("6560ns"))); // Hay que editar los datos
  csmaDevicesDerecha = csmaDerecha.Install (csmaNodesDerecha);

  CsmaHelper csmaIzquierda;
  NetDeviceContainer csmaDevicesIzquierda;
  csmaIzquierda.SetChannelAttribute ("DataRate", DataRateValue (DataRate ("100Mbps")));// Hay que editar los datos
  csmaIzquierda.SetChannelAttribute ("Delay", TimeValue (Time ("6560ns")));// Hay que editar los datos
  csmaDevicesIzquierda = csmaIzquierda.Install (csmaNodesIzquierda);
  
  //----------------------------------------------------------------------------
  //
  //Ahora viene la creación e instalación de los teléfonos IP
  //
  //----------------------------------------------------------------------------
  
  //Se crean los telefonos IP, de momento sólo vamos a tener uno en cada red
  NodeContainer TelefonoVoipIzq;
  NodeContainer TelefonoVoipDer;
  TelefonoVoipIzq.Create(1);
  TelefonoVoipDer.Create(1);
  //Se añaden los routers al node container.
  TelefonoVoipIzq.Add(p2pNodes.Get(0));
  TelefonoVoipDer.Add(p2pNodes.Get(1));

  //Ahora se pone un Netdevice asociado al telefono de la izquierda
  //junto al device de su router
  NetDeviceContainer R1DeviceTel;
  NetDeviceContainer R1DeviceRouter;
  NetDeviceContainer enlace = pointToPoint.Install(NodeContainer(TelefonoVoipIzq.Get(0), p2pNodes.Get(0)));
  R1DeviceTel.Add(enlace.Get(0));
  R1DeviceRouter.Add(enlace.Get(1));

  //Ahora se pone un Netdevice asociado al telefono de la derecha 
  //junto al device de su router 
  NetDeviceContainer R2DeviceTel;
  NetDeviceContainer R2DeviceRouter;
  NetDeviceContainer enlace2 = pointToPoint.Install(NodeContainer(TelefonoVoipDer.Get(0), p2pNodes.Get(1)));
  R2DeviceTel.Add(enlace2.Get(0));
  R2DeviceRouter.Add(enlace2.Get(1));

 //----------------------------------------------------------------------------

  //Se monta la pila de protocolos
  InternetStackHelper stack;
  stack.Install (csmaNodesIzquierda);
  stack.Install (csmaNodesDerecha);
  InternetStackHelper stack2;
  stack2.Install(TelefonoVoipIzq);
  stack2.Install(TelefonoVoipDer);


  NetDeviceContainer R1Devices;       
  NetDeviceContainer R2Devices;      
  R1Devices.Add(R1DeviceTel);
  R1Devices.Add(R1DeviceRouter);
  R2Devices.Add(R2DeviceTel);
  R2Devices.Add(R2DeviceRouter);




  //----------------------------------------------------------------------------
  // Asignamos direcciones a cada una de las interfaces
  // Utilizamos dos rangos de direcciones diferentes:
  //    - un rango para los dos nodos del enlace
  //      punto a punto
  //    - un rango para los nodos de la red de área local izquierda.
  //    - un rango para los nodos de la red de área local derecha.
  //----------------------------------------------------------------------------
  
  
  //Network de los dos nodos del enlace punto a punto
  Ipv4AddressHelper address;
  
  Ipv4InterfaceContainer p2pInterfaces;
  address.SetBase ("10.0.0.0", "255.255.255.0");
  p2pInterfaces = address.Assign (p2pDevices);

  Ipv4InterfaceContainer telIpDer;
  address.SetBase("10.1.1.0","255.255.255.0");
  telIpDer = address.Assign(R1Devices);

  Ipv4InterfaceContainer telIpIzq;
  address.SetBase("10.2.2.0","255.255.255.0");
  telIpIzq = address.Assign(R2Devices);
  //TO-DO: Meter los teléfonos IP en la misma network que los demás equipos
  
  /*
  Ipv4InterfaceContainer csmaIzquierdaInterfaces;
  address.SetBase ("10.1.1.0", "255.255.255.0");
  csmaIzquierdaInterfaces = address.Assign (csmaDevicesIzquierda);

  Ipv4InterfaceContainer csmaDerechaInterfaces;
  address.SetBase ("10.2.2.0", "255.255.255.0");
  csmaDerechaInterfaces = address.Assign (csmaDevicesDerecha);
  */



  //Ruta estática para ambos telefonos 
  Ipv4StaticRoutingHelper ipv4RoutingHelper;
  Ptr<Ipv4StaticRouting> t1 = ipv4RoutingHelper.GetStaticRouting(TelefonoVoipIzq.Get(0)->GetObject<Ipv4>());
  Ipv4Address direccion("10.1.1.0");
  t1->SetDefaultRoute(Ipv4Address(direccion.Get() +1 ),1);
  //Aquí se debería incluir una linea para cada equipo en esta red 

  Ipv4StaticRoutingHelper ipv4RoutingHelper2;
  Ptr<Ipv4StaticRouting> t2 = ipv4RoutingHelper2.GetStaticRouting(TelefonoVoipIzq.Get(1)->GetObject<Ipv4>());
  Ipv4Address direccion2("10.2.2.0");
  t2->SetDefaultRoute(Ipv4Address(direccion2.Get() +1 ),1);
  //Aquí se debería incluir una linea para cada equipo en esta red 



  //Montar el envío de paquetes VoIP
  // ¡No funciona! y NO se cual de estas dos formas es más correcto:
        // AplicacionTelefonoIzq = new Voip();
              // TelefonoVoipIzq.Get(0)->AddApplication(AplicacionTelefonoIzq);
        // Ptr<Voip> AplicacionTelefonoIzq = CreateObject<Voip> ();
  AplicacionTelefonoIzq = new Voip();
  TelefonoVoipIzq.Get(0)->AddApplication(AplicacionTelefonoIzq);
  AplicacionTelefonoIzq->SetStartTime(Seconds(2.0));
  AplicacionTelefonoIzq->SetStopTime(Seconds(10.0));

  AplicacionTelefonoDer = new Voip();
  TelefonoVoipDer.Get(0)->AddApplication(AplicacionTelefonoDer);
  AplicacionTelefonoDer->SetStartTime(Seconds(2.0));
  AplicacionTelefonoDer->SetStopTime(Seconds(10.0));


  // Calculamos las rutas del escenario. Con este comando, los
  //     nodos de la red de área local definen que para acceder
  //     al nodo del otro extremo del enlace punto a punto deben
  //     utilizar el primer nodo como ruta por defecto.
  Ipv4GlobalRoutingHelper::PopulateRoutingTables ();

//-----------------------------------------------------------------------------
// Aplicación de la práctica 6:
//-----------------------------------------------------------------------------

  // Establecemos un sumidero para los paquetes en el puerto 9 del nodo
  //     aislado del enlace punto a punto
  uint16_t port = 9;
  PacketSinkHelper sink ("ns3::UdpSocketFactory",
                         Address (InetSocketAddress (Ipv4Address::GetAny (),
                                                     port)));
  ApplicationContainer app = sink.Install (p2pNodes.Get (0));

  // Instalamos un cliente OnOff en uno de los equipos de la red de área local
  OnOffHelper clientes ("ns3::UdpSocketFactory",
                        Address (InetSocketAddress (p2pInterfaces.GetAddress (0),
                                                    port)));

  ApplicationContainer clientApps = clientes.Install (csmaNodesDerecha.Get (nCsmaDerecha));
  clientApps.Start (Time ("2s"));
  clientApps.Stop (Time ("10s"));

  // Activamos las trazas pcap en las dos interfaces del nodo de enlace
  pointToPoint.EnablePcap ("Trabajo", p2pDevices.Get (0));
  csmaDerecha.EnablePcap ("Trabajo", csmaDevicesDerecha.Get (0), true);

  
  NS_LOG_DEBUG("Creando la cola");
  Prioridad prioridad;

  // Lanzamos la simulación
  Simulator::Run ();
  Simulator::Destroy ();

  return 0;
}
