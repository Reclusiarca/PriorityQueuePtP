/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/csma-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/ipv4-global-routing-helper.h"
//#include "Prioridad.h"
#include "VOIP.h"

///
// n0 n1 n2 n3 n4 - - - - - - n5 n6 n7 n8 n9
//  | |  |  |  |              |  |  |  |  |
// ==============             =============
//      Lan1           p2p          Lan2


// Lan 1 :  10.1.1.0
// p2p   :  10.0.0.0
// Lan 2 :  10.2.2.0

//n0 = equipo que genera VoIP 
//n1 = equipo que emite en streaming
//n2 = equipo que descarga HTTP
//n3 = equipo que descarga por FTP

//n4 = router de LAN 1
//n5 = router de LAN 2

//n6 = equipo que genera VoIP 
//n7 = equipo que emite en streaming
//n8 = equipo que descarga HTTP
//n9 = equipo que descarga por FTP

// ¿Qué hay hecho?

/* Bueno en principio se definen dos redes csma y una red p2p,
   como en el esquema de arriba.
   
   Se crea un NodeContainer para red CSMA Izquierda
   Se crea un NodeContainer para red CSMA Derecha
   Se crea un NodeContainer para red p2p 
   Se crea un NodeContainer para los telefonos IP de la izquierda
   Se crea un NodeContainer para los telefonos IP de la derecha
   
   He aquí una pregunta, ¿Por qué no se ha junta nodos de teléfono IP y "CSMA"?
   Por que así me parece que no van a compartir misma subred.
   
   Se montan entonces los NetDevice y se asocian a sus NodeContainer, 
   haciendo nuevamente distinción entre "CSMA" y "VoIP"
   Por cierto, en este punto comienzan a ponerse confusas los nombres de las variables
   o usamos Izquierda/Derecha ó R1/R2.
   
   Se monta la pila de protocolos y se configuran las network
   TO-DO: Meter los teléfonos IP en la misma network que los demás equipos
   
   A la hora de configurar las networks se pone una linea 
   t2->SetDefaultRoute(Ipv4Address(direccion2.Get() +1 ),1);
   para su configuración estática de IP.
   
   Se instala la aplicación.
   Pero la aplicación da problemas al ser invocada!
   ¡No funciona! y NO se cual de estas dos formas es más correcto:
      - AplicacionTelefonoIzq = new Voip();
      - Ptr<Voip> AplicacionTelefonoIzq = CreateObject<Voip> ();
   
   Después sigue estando la configuración del sumidero de la práctica 6 (?)
   */




using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("Trabajo");

int
main (int argc, char *argv[])
{
  GlobalValue::Bind("ChecksumEnabled", BooleanValue(true));
  Time::SetResolution (Time::NS);

  uint32_t nCsmaIzquierda = 4;
  uint32_t nCsmaDerecha = 4;
  Time hablando=Seconds(1.0);
  Time silencio=Seconds(0.5); 
  Time retardo=Seconds(0.2);
  uint32_t tamPqt=121;
  Time tinicio=Seconds(1.0);
  Time tfinal= Seconds(10.0);

 
  // Nodos que pertenecen al enlace punto a punto
  NodeContainer p2pNodes;
  p2pNodes.Create (2);

  // Nodos que pertenecen a la red de área local
  // Como primer nodo añadimos el encaminador que proporciona acceso
  //      al enlace punto a punto.
  NodeContainer csmaNodesDerecha;
  csmaNodesDerecha.Add (p2pNodes.Get (1));
  csmaNodesDerecha.Create (nCsmaDerecha);
  NodeContainer csmaNodesIzquierda;
  csmaNodesIzquierda.Add (p2pNodes.Get (0));
  csmaNodesIzquierda.Create (nCsmaIzquierda);

  //Instalamos el dispositivo en los nodos punto a punto
  PointToPointHelper pointToPoint;
  NetDeviceContainer p2pDevices;
  pointToPoint.SetDeviceAttribute ("DataRate", DataRateValue (DataRate ("2Mbps"))); // Hay que editar los datos
  pointToPoint.SetChannelAttribute ("Delay", TimeValue (Time ("2ms")));// Hay que editar los datos
  p2pDevices = pointToPoint.Install (p2pNodes);

  // Instalamos el dispositivo de red en los nodos de las LAN
  CsmaHelper csmaDerecha;
  NetDeviceContainer csmaDevicesDerecha;
  csmaDerecha.SetChannelAttribute ("DataRate", DataRateValue (DataRate ("100Mbps")));// Hay que editar los datos
  csmaDerecha.SetChannelAttribute ("Delay", TimeValue (Time ("6560ns"))); // Hay que editar los datos
  csmaDevicesDerecha = csmaDerecha.Install (csmaNodesDerecha);

  CsmaHelper csmaIzquierda;
  NetDeviceContainer csmaDevicesIzquierda;
  csmaIzquierda.SetChannelAttribute ("DataRate", DataRateValue (DataRate ("100Mbps")));// Hay que editar los datos
  csmaIzquierda.SetChannelAttribute ("Delay", TimeValue (Time ("6560ns")));// Hay que editar los datos
  csmaDevicesIzquierda = csmaIzquierda.Install (csmaNodesIzquierda);
  /*
  //----------------------------------------------------------------------------
  //
  //Ahora viene la creación e instalación de los teléfonos IP
  //
  //----------------------------------------------------------------------------
  */
  
  /*
  //Se crean los telefonos IP, de momento sólo vamos a tener uno en cada red
  NodeContainer TelefonoVoipIzq;
  NodeContainer TelefonoVoipDer;
  TelefonoVoipIzq.Create(1);
  TelefonoVoipDer.Create(1);
  //Se añaden los routers al node container.
  TelefonoVoipIzq.Add(p2pNodes.Get(0));
  TelefonoVoipDer.Add(p2pNodes.Get(1));

  //Ahora se pone un Netdevice asociado al telefono de la izquierda
  //junto al device de su router
  NetDeviceContainer R1DeviceTel;
  NetDeviceContainer R1DeviceRouter;
  NetDeviceContainer enlace = pointToPoint.Install(NodeContainer(TelefonoVoipIzq.Get(0), p2pNodes.Get(0)));
  R1DeviceTel.Add(enlace.Get(0));
  R1DeviceRouter.Add(enlace.Get(1));

  //Ahora se pone un Netdevice asociado al telefono de la derecha 
  //junto al device de su router 
  NetDeviceContainer R2DeviceTel;
  NetDeviceContainer R2DeviceRouter;
  NetDeviceContainer enlace2 = pointToPoint.Install(NodeContainer(TelefonoVoipDer.Get(0), p2pNodes.Get(1)));
  R2DeviceTel.Add(enlace2.Get(0));
  R2DeviceRouter.Add(enlace2.Get(1));
  */
 //----------------------------------------------------------------------------

  //Se monta la pila de protocolos
  InternetStackHelper stack;
  stack.Install (csmaNodesIzquierda);
  stack.Install (csmaNodesDerecha);
  /* InternetStackHelper stack2;
  stack2.Install(TelefonoVoipIzq);
  stack2.Install(TelefonoVoipDer);
  */
  /*
  NetDeviceContainer R1Devices;       
  NetDeviceContainer R2Devices;      
  R1Devices.Add(R1DeviceTel);
  R1Devices.Add(R1DeviceRouter);
  R2Devices.Add(R2DeviceTel);
  R2Devices.Add(R2DeviceRouter);


  */

  //----------------------------------------------------------------------------
  // Asignamos direcciones a cada una de las interfaces
  // Utilizamos dos rangos de direcciones diferentes:
  //    - un rango para los dos nodos del enlace
  //      punto a punto
  //    - un rango para los nodos de la red de área local izquierda.
  //    - un rango para los nodos de la red de área local derecha.
  //----------------------------------------------------------------------------
  
  
  //Network de los dos nodos del enlace punto a punto
  Ipv4AddressHelper address;
  
  Ipv4InterfaceContainer p2pInterfaces;
  address.SetBase ("10.0.0.0", "255.255.255.0");
  p2pInterfaces = address.Assign (p2pDevices);
 
  
  Ipv4InterfaceContainer csmaIzquierdaInterfaces;
  address.SetBase ("10.1.1.0", "255.255.255.0");
  csmaIzquierdaInterfaces = address.Assign (csmaDevicesIzquierda);

  Ipv4InterfaceContainer csmaDerechaInterfaces;
  address.SetBase ("10.2.2.0", "255.255.255.0");
  csmaDerechaInterfaces = address.Assign (csmaDevicesDerecha);
  /*



  //Ruta estática para ambos telefonos 
  Ipv4StaticRoutingHelper ipv4RoutingHelper;
  Ptr<Ipv4StaticRouting> t1 = ipv4RoutingHelper.GetStaticRouting(TelefonoVoipIzq.Get(0)->GetObject<Ipv4>());
  Ipv4Address direccion("10.1.1.0");
  t1->SetDefaultRoute(Ipv4Address(direccion.Get() +1 ),1);
  //Aquí se debería incluir una linea para cada equipo en esta red 

  Ipv4StaticRoutingHelper ipv4RoutingHelper2;
  Ptr<Ipv4StaticRouting> t2 = ipv4RoutingHelper2.GetStaticRouting(TelefonoVoipIzq.Get(1)->GetObject<Ipv4>());
  Ipv4Address direccion2("10.2.2.0");
  t2->SetDefaultRoute(Ipv4Address(direccion2.Get() +1 ),1);
  //Aquí se debería incluir una linea para cada equipo en esta red 



  //Montar el envío de paquetes VoIP
  // ¡No funciona! y NO se cual de estas dos formas es más correcto:
        // AplicacionTelefonoIzq = new Voip();
              // TelefonoVoipIzq.Get(0)->AddApplication(AplicacionTelefonoIzq);
        // Ptr<Voip> AplicacionTelefonoIzq = CreateObject<Voip> ();
  AplicacionTelefonoIzq = new Voip();
  TelefonoVoipIzq.Get(0)->AddApplication(AplicacionTelefonoIzq);
  AplicacionTelefonoIzq->SetStartTime(Seconds(2.0));
  AplicacionTelefonoIzq->SetStopTime(Seconds(10.0));

  AplicacionTelefonoDer = new Voip();
  TelefonoVoipDer.Get(0)->AddApplication(AplicacionTelefonoDer);
  AplicacionTelefonoDer->SetStartTime(Seconds(2.0));
  AplicacionTelefonoDer->SetStopTime(Seconds(10.0));
  */

  // Calculamos las rutas del escenario. Con este comando, los
  //     nodos de la red de área local definen que para acceder
  //     al nodo del otro extremo del enlace punto a punto deben
  //     utilizar el primer nodo como ruta por defecto.
  Ipv4GlobalRoutingHelper::PopulateRoutingTables ();

//-----------------------------------------------------------------------------
// Aplicación de la práctica 6:
//-----------------------------------------------------------------------------

  // Establecemos 4 sumideros para los paquetes HTTP,VoIP,Streaming y FTP en los nodos de la izquierda

  uint16_t portVOIP = 9;//puerto inventado
  uint16_t portHTTP = 80;
  uint16_t portFTP = 20;
  uint16_t portstreaming = 1022;

  /********Instalamos los sumideros correspondientes a cada servicio **********/
  
  PacketSinkHelper sinkVoIP ("ns3::UdpSocketFactory",
                         Address (InetSocketAddress (Ipv4Address::GetAny (),
                                                     portVOIP)));
  PacketSinkHelper sinkHTTP ("ns3::TcpSocketFactory",
                         Address (InetSocketAddress (Ipv4Address::GetAny (),
                                                     portHTTP)));
  PacketSinkHelper sinkFTP ("ns3::TcpSocketFactory",
			    Address (InetSocketAddress (Ipv4Address::GetAny (),
							portFTP)));
  PacketSinkHelper sinkStreaming ("ns3::UdpSocketFactory",
                         Address (InetSocketAddress (Ipv4Address::GetAny (),
                                                     portstreaming)));
  
 
 ApplicationContainer app = sinkFTP.Install (csmaNodesIzquierda.Get(1));
 ApplicationContainer app1 = sinkVoIP.Install ( csmaNodesIzquierda.Get(2));
 ApplicationContainer app2 = sinkHTTP.Install ( csmaNodesIzquierda.Get(3));
 ApplicationContainer app3 = sinkStreaming.Install (csmaNodesIzquierda.Get(4));


 //Creamos los OnOffHelper excepto para VoIP que tenemos nuestra propia app (de momento straming si que tiene onoffhelper)
 OnOffHelper clientesFTP ("ns3::TcpSocketFactory",
                        Address (InetSocketAddress (csmaIzquierdaInterfaces.GetAddress (1),
						    portFTP)));
 /* OnOffHelper clientesVOIP ("ns3::UdpSocketFactory",
                        Address (InetSocketAddress (csmaIzquierdaInterfaces.GetAddress (2),
			portVOIP)));*/
 OnOffHelper clientesHTTP ("ns3::TcpSocketFactory",
                        Address (InetSocketAddress (csmaIzquierdaInterfaces.GetAddress (3),
					                                                  portHTTP)));
 OnOffHelper clientesStreaming ("ns3::UdpSocketFactory",
                        Address (InetSocketAddress (csmaIzquierdaInterfaces.GetAddress (4),
					                                                  portstreaming)));

 //Creamos el socket en el telefono 1
 Ptr<Socket> ns3UdpSocket = Socket::CreateSocket (csmaNodesDerecha.Get(2), 
						  UdpSocketFactory::GetTypeId ());

 Ptr <VoIP> telefono = 
CreateObject<VoIP> (ns3UdpSocket,csmaIzquierdaInterfaces.GetAddress (2),tamPqt,hablando,silencio,retardo);
 
 csmaNodesDerecha.Get(2)->AddApplication(telefono);

 csmaDevicesDerecha.Get (2)->
    SetReceiveCallback (ns3::MakeCallback (&VoIP::NuevoPaquete,
                                           telefono));
 telefono->SetStartTime(Seconds(2.0));
 telefono->SetStopTime (Seconds(10.0));
 
 ApplicationContainer clientAppsFTP = clientesFTP.Install (csmaNodesDerecha.Get (1));
 clientAppsFTP.Start (Time ("2s"));
 clientAppsFTP.Stop (Time ("10s"));

 ApplicationContainer clientAppsHTTP = clientesHTTP.Install (csmaNodesDerecha.Get (3));
 clientAppsHTTP.Start (Time ("2s"));
 clientAppsHTTP.Stop (Time ("10s"));
 ApplicationContainer clientAppsStreaming = clientesStreaming.Install (csmaNodesDerecha.Get (4));
 clientAppsStreaming.Start (Time ("2s"));
 clientAppsStreaming.Stop (Time ("10s"));

  // Activamos las trazas de todas las interfaces
 csmaIzquierda.EnablePcap ("Trabajo1", csmaDevicesIzquierda.Get (0), false);//Desactivamos modo promiscuo con false
 csmaIzquierda.EnablePcap ("Trabajo2", csmaDevicesIzquierda.Get (1), false);
 csmaIzquierda.EnablePcap ("Trabajo3", csmaDevicesIzquierda.Get (2), false);
 csmaIzquierda.EnablePcap ("Trabajo4", csmaDevicesIzquierda.Get (3), false);
 csmaDerecha.EnablePcap ("Trabajo5", csmaDevicesDerecha.Get (0), false);
 csmaDerecha.EnablePcap ("Trabajo6", csmaDevicesDerecha.Get (1), false);
 csmaDerecha.EnablePcap ("Trabajo7", csmaDevicesDerecha.Get (2), false);
 csmaDerecha.EnablePcap ("Trabajo8", csmaDevicesDerecha.Get (3), false);
 
  /* 
  NS_LOG_DEBUG("Creando la cola");
  Prioridad prioridad;
  */
  // Lanzamos la simulación
  Simulator::Run ();
  Simulator::Destroy ();

  return 0;
}
