/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#include <ns3/core-module.h>
#include <ns3/node.h>
#include <ns3/point-to-point-net-device.h>
#include <ns3/point-to-point-channel.h>
#include "ns3/point-to-point-module.h"
#include <ns3/drop-tail-queue.h>
#include <ns3/random-variable-stream.h>
#include <ns3/command-line.h>
#include <ns3/gnuplot.h>
#include <ns3/average.h>
#include <ns3/error-model.h>
#include <ns3/random-variable-stream.h>
#include <ns3/packet.h>
#include "ns3/network-module.h"
#include "ns3/net-device.h"
#include "ns3/application.h"
#include <ns3/random-variable-stream.h>
#include "VOIP.h"

#define RETARDO 1500



using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("VOIP");

VOIP::VOIP (TypeId socket, Address remote, uint32_t packetSize,Time          hablando, Time silencio,
            Time retardo)
  {
    m_tid=socket;
    remote=m_peer;
    m_packetSize = packetSize;
    t_hablando = hablando;
    t_silencio = silencio;
    t_retardo = retardo;
  }
  
bool
VOIP::NuevoPaquete (Ptr<NetDevice>        receptor,
              Ptr<const Packet>     recibido,
              uint16_t              protocolo,
              const Address &       desde){
  
  //Funcion que comprueba si el paquete recibido es un paquete de datos o un ACK
  //Y llama a la funcion pertinente para que trate al mismo.

  NS_LOG_FUNCTION_NOARGS ();
  NS_LOG_FUNCTION (receptor << recibido->GetSize () << std::hex << protocolo << desde);
  
  if (recibido->GetSize() >= 2){
      //Si el paquete recibido es un paquete de Datos
      DatosRecibidos (recibido);
  }
  return true;
}
void
VOIP::EnviaDatos (){
  //Esta funcion se encargara de enviar paquetes de datos. 
  //En primer lugar genera un numero aleatorio para saber cuantos paquetes tiene que transmitir
  //Una vez enviados iniciamos:
    //Un temporizador para esperar a transmitir cada uno de los paquetes de datos
    //Otro temporizador al acabar de transmitir los paquetes.

NS_LOG_FUNCTION_NOARGS ();

// Modificar esta parte para simular el envio de paquetes 
 double min = 0.0;
 double max = t_hablando.GetSeconds();
 Ptr<UniformRandomVariable> x = CreateObject<UniformRandomVariable> ();
 x->SetAttribute ("Min", DoubleValue (min));
 x->SetAttribute ("Max", DoubleValue (max));
     
 double value = x->GetValue (); //Value es el nº de paquetes que se van a transmitir
 std::cout<<"Envio   " << value << " paquetes"<< std::endl;
 //Enviaremos tantos paquetes como "value"

    for ( uint8_t aux = 0 ; aux < value ; aux++ )
      {
        std::cout<<"¿Cuantas veces entro?   "<< std::endl;
	/*
       t_enviado= Simulator::Now();
       //Cogemos el identificador para asociarle el tiempo en el que se envio
       uint64_t id = paquete->GetUid();
        array[id]=t_enviado;
	*/
        //const uint8_t algo = 1; 
        //uint8_t t_enviado= Simulator::Now().GetMilliSeconds();
        //Ptr<Packet> paquete = Create<Packet> ( &t_enviado, m_packetSize + 1);
        m_socket->Send(Create<Packet> (m_packetSize));
      }
    
    
    
    //Activamos temporizador para estar callados ese tiempo  
    m_temporizador=Simulator::Schedule(t_silencio,&VOIP::VenceTemporizador,this);
}
void
VOIP::DatosRecibidos (Ptr<const Packet> paquete)
{
  /*
   NS_LOG_FUNCTION_NOARGS ();
   std::map<uint64_t,Time>::iterator aux=array.find(paquete->GetUid());
   if (array.end() == aux)
    {
      NS_LOG_WARN("NO ESTA EN LA ESTRUCTURA");
    }
  else
  {
      Simulator::Cancel( m_temporizador);
      NS_LOG_DEBUG("SI ESTA EN LA ESTRUCTURA");
      Time Taux =array[paquete->GetUid()];
      double TretardoPkt = (Simulator::Now()-Taux).GetMilliSeconds();
        if(TretardoPkt <= retardo.GetMilliSeconds()){
          //    retardo.Update( TretardoPkt);//Actualizamos acumulador
        }
      //Borrado de elementos
      array.erase(aux);
      }*/
    m_temporizador=Simulator::Schedule(t_silencio,&VOIP::VenceTemporizador,this);//Activamos temporizador para estar callados ese tiempo 

}

void VOIP:: VenceTemporizador()
{
  double min = 0.0;
 double max = 100.0;
 Ptr<UniformRandomVariable> x = CreateObject<UniformRandomVariable> ();
 x->SetAttribute ("Min", DoubleValue (min));
 x->SetAttribute ("Max", DoubleValue (max));
 double value = x->GetValue ();
 //Aqui decidimos quien empieza a hablar aleatoriamente. Si el valor que escogemos es menor que un umbral que hemos decidido, empezara a enviar, de lo contrario, iniciaremos de nuevo el temporizador y esperaremos. 
 std::cout<< "El valor es " << value << std::endl;
if (value<30.0)
   {
     std::cout <<"  entro?" << std::endl;
     EnviaDatos();
   }
 else
   m_temporizador=Simulator::Schedule(t_silencio,&VOIP::VenceTemporizador,this);
      }

void VOIP::ConnectionSucceeded (Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << socket);
  m_connected = true;
}

void VOIP::ConnectionFailed (Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << socket);
}

