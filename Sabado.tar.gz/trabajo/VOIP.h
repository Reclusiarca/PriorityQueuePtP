/* -*- Mode:C++; c-file-style:''gnu''; indent-tabs-mode:nil; -*- */
  /*
   * This program is free software; you can redistribute it and/or modify
   * it under the terms of the GNU General Public License version 2 as
   * published by the Free Software Foundation;
   *
   * This program is distributed in the hope that it will be useful,
   * but WITHOUT ANY WARRANTY; without even the implied warranty of
   * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   * GNU General Public License for more details.
   *
   * You should have received a copy of the GNU General Public License
   * along with this program; if not, write to the Free Software
   * Foundation, Include., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
   */
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/node.h"
#include "ns3/net-device.h"
#include "ns3/application.h"
  
  using namespace ns3;
  
class VoIP : public Application
  {
  public:
  
    VoIP ()
    {

    }
  VoIP (Ptr<Socket> socket, Address address, uint32_t packetSize,Time          hablando, Time silencio,
	        Time retardo
	);
static TypeId 
  GetTypeId (void)
  {
    static TypeId tid = TypeId ("ns3::VoIP")
      .SetParent<Application> ()
      //      .AddConstructor<Enlace> ()
      //.AddTraceSource ("NuevoPaquete", 
        //               "Trace source indicating a new packet has been generated",
          //             MakeTraceSourceAccessor (&VoIP::m_nuevoPaquete));
    ;
    return tid;
  }

    bool
    NuevoPaquete (Ptr<NetDevice>        receptor,
		  Ptr<const Packet>     recibido,
		  uint16_t              protocolo,
		  const Address &       desde);
    
  // Función de vencimiento del temporizador
    void
    VenceTemporizador ();
    
  private:
     void StartApplication ()
     {
      m_running = true;
      m_packetsSent = 0;
      m_socket->Bind ();
      m_socket->Connect (m_peer);
      VenceTemporizador ();
     }
     void StopApplication ()
     {
      m_running = false;
  
    if (m_sendEvent.IsRunning ())
      {
        Simulator::Cancel (m_sendEvent);
      }
  
    if (m_socket)
      {
        m_socket->Close ();
      }
    Simulator::Stop (); m_running = false;
     }
    void
  DatosRecibidos (Ptr<const Packet> paquete);
    
  // Función que envía un paquete de datos.
  void
  EnviaDatos (Ptr<const Packet> paquet);
  
    void ScheduleTx (void);
    void SendPacket (void);
  
    Ptr<Socket>     m_socket;
    Address         m_peer;
    uint32_t        m_packetSize;
    Time            t_hablando;
    Time            t_silencio;
    Time            t_retardo;
    EventId         m_sendEvent;
    bool            m_running;
    uint32_t        m_packetsSent;
    EventId        m_temporizador;
  };

